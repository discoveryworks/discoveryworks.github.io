# Pizza Labs Brand Kit

Assets for press, marketing, and partner use.

## Icons (1024x1024)
- `icons/pizzaroids_1024.png` - Pizzaroids app icon
- `icons/pizza_ping_1024.png` - Pizza Ping app icon
- `icons/pizza_pong_1024.png` - Pizza Pong app icon
- `icons/tic_tac_pizza_1024.png` - Tic Tac Pizza app icon
- `icons/ms_pizza_man_1024.png` - Ms. Pizza-Man app icon

## Screenshots
- `screenshots/tic_tac_pizza_*.png` - Tic Tac Pizza gameplay
- More coming soon

## Usage
All assets © 2025 Pizza Labs / Discovery Works.
Free to use for press, reviews, and coverage of Pizza Labs games.

## Download
Full brand kit: https://discovery.works/labs/pizza/brand_kit.zip

For press inquiries: [contact email]
